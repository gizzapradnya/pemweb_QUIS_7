const mysql = require('mysql');

// Konfigurasi koneksi database
const db = mysql.createConnection({
    host: 'localhost', // Sesuaikan dengan konfigurasi MySQL Anda
    user: 'root',      // Sesuaikan dengan username MySQL Anda
    password: '',      // Isi dengan password MySQL jika ada, kosongkan jika tidak
    database: 'users' // Nama database yang digunakan
});

// Fungsi untuk menghubungkan ke database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err.message);
        return;  // Pastikan tidak melempar error, gunakan return
    }
    console.log('Database connected successfully!');
});

module.exports = db;
